/*
 * FreeRTOS V202007.00
 * Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://aws.amazon.com/freertos
 * http://www.FreeRTOS.org
 */

#ifndef AWS_CLIENT_CREDENTIAL_KEYS_H
#define AWS_CLIENT_CREDENTIAL_KEYS_H

/*
 * PEM-encoded client certificate
 *
 * Must include the PEM header and footer:
 * "-----BEGIN CERTIFICATE-----\n"\
 * "...base64 data...\n"\
 * "-----END CERTIFICATE-----\n"
 */
#define keyCLIENT_CERTIFICATE_PEM \
"-----BEGIN CERTIFICATE-----\n"\
"MIIDWTCCAkGgAwIBAgIUJRqNLIHvdycCKWMy0Ay48LseeVowDQYJKoZIhvcNAQEL\n"\
"BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\n"\
"SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTIwMDgxMTA2NTgz\n"\
"OVoXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0\n"\
"ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAL1st26ECJqFYMyQVAmN\n"\
"S0/YHElvOa0me3qCjJNKcMi8G9/3hIVJDMDqbJujU2KYHOEIn+gDvbjDtK867phA\n"\
"usZ9TTwVqKNkxlUebMqlDWj4CbtW58tFkAZgpzqplUu2vCQGmYeTRrqM/DXwddMY\n"\
"S8vYajQIHHKFed8pOdjqPfXRykKypCfJWgvcsG7e+yTCfdBrXK49cT35gTk4ZoN8\n"\
"3Dk3ZPneNJx4Zj/Mg9MHAhkQpCyFTKv5E7xQgDZxXEPJMQJ8AM9a2bETFg8yGoEb\n"\
"rFuu7sro3xotFcyNvywPB+1srJHDz1fqyIFVppfC2Vpq0J+Xel3ksJqAJEwbbwQ4\n"\
"mJ8CAwEAAaNgMF4wHwYDVR0jBBgwFoAUohwObl32XPqBFEd4hVgjd4/WR5wwHQYD\n"\
"VR0OBBYEFMC9UJv00a8GfrM8Ca2cd3iuAXGkMAwGA1UdEwEB/wQCMAAwDgYDVR0P\n"\
"AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQAUpFv6kPIfgBL2oXEA2/vSv7u/\n"\
"zJjOkvEifiu5mAhLHGr/2Hw205R1gcNJHkOPbpygHgNc2RIbHIZ0RQr0YUrqc6NR\n"\
"xdwpYDp6HARB+qHyXuyohzQbVeQ1Xb4szfyKbLs9UU0AzE215/DWUxw9r8+CGDJq\n"\
"gXm27K8zypEAMEwMi5nEk9mV7g9o25LF2p3PsOfqv020a2bcKsc0bBuwOMAfozSP\n"\
"Y/XeOi44s2A7/MX6LWHik58UAVMpGgoLQ022L+nsXMuTzpcpGA3EsI0sD01qA825\n"\
"aUh1VfECURbgfzHF+dWSP23+LUXGwYJ5Wy1rpOT9UZBH+DTPfObuEWdM2xQU\n"\
"-----END CERTIFICATE-----\n"

/*
 * PEM-encoded issuer certificate for AWS IoT Just In Time Registration (JITR).
 * This is required if you're using JITR, since the issuer (Certificate
 * Authority) of the client certificate is used by the server for routing the
 * device's initial request. (The device client certificate must always be
 * sent as well.) For more information about JITR, see:
 *  https://docs.aws.amazon.com/iot/latest/developerguide/jit-provisioning.html,
 *  https://aws.amazon.com/blogs/iot/just-in-time-registration-of-device-certificates-on-aws-iot/.
 *
 * If you're not using JITR, set below to NULL.
 *
 * Must include the PEM header and footer:
 * "-----BEGIN CERTIFICATE-----\n"\
 * "...base64 data...\n"\
 * "-----END CERTIFICATE-----\n"
 */
#define keyJITR_DEVICE_CERTIFICATE_AUTHORITY_PEM  ""

/*
 * PEM-encoded client private key.
 *
 * Must include the PEM header and footer:
 * "-----BEGIN RSA PRIVATE KEY-----\n"\
 * "...base64 data...\n"\
 * "-----END RSA PRIVATE KEY-----\n"
 */
#define keyCLIENT_PRIVATE_KEY_PEM \
"-----BEGIN RSA PRIVATE KEY-----\n"\
"MIIEpAIBAAKCAQEAvWy3boQImoVgzJBUCY1LT9gcSW85rSZ7eoKMk0pwyLwb3/eE\n"\
"hUkMwOpsm6NTYpgc4Qif6AO9uMO0rzrumEC6xn1NPBWoo2TGVR5syqUNaPgJu1bn\n"\
"y0WQBmCnOqmVS7a8JAaZh5NGuoz8NfB10xhLy9hqNAgccoV53yk52Oo99dHKQrKk\n"\
"J8laC9ywbt77JMJ90Gtcrj1xPfmBOThmg3zcOTdk+d40nHhmP8yD0wcCGRCkLIVM\n"\
"q/kTvFCANnFcQ8kxAnwAz1rZsRMWDzIagRusW67uyujfGi0VzI2/LA8H7WyskcPP\n"\
"V+rIgVWml8LZWmrQn5d6XeSwmoAkTBtvBDiYnwIDAQABAoIBABhCOQedPyDS3f+0\n"\
"qB6FCtUR3yWEagWDvSKGX4xpZyI9/O/k2gLbxRdbrkcMVpx00JX9LcVf3UcxQQ2D\n"\
"5ZR4DbNnzqFYQL2UJVY3TEVzd9Eumsh0K8E7imNWs3PuzeDhaRzP/49+S/uOHKqn\n"\
"vd8n6GUVtRwuwb3k3CO5OuBNt1uoptNl+kmwExmJBdR+/AKx+hTnA+ONUEwV3NXZ\n"\
"FC0I+jgO4Uqjb9LFdJfgCmpw7oQP3x9+mJd/GQkrw36n995kkEO9sIRVVnyLPPg4\n"\
"R/JO2+nyMOCXdKvGk2KLVX3io7wc5lbq4g15QMF0AFWccrcEFDIlbEsNxwA7z4uZ\n"\
"yzD5IMkCgYEA6pGet9F72K6J/3tGyHGhkNkQ/P7+GVj1w2s8y7b0FhWggsWMKuYC\n"\
"tF9R6eZpzyr905ZgEOpGutNTuMxCSsVorjdiiz/4QBjA9epwKIkgdvMJ4GEXp5KG\n"\
"/pZI41Ir4e7TE0kiYjB0gTAJqnA/YVcNVRbDAQIdmIQnBPWUbvgVLeUCgYEAzrs1\n"\
"2b3IncYANCdUtomV95Wfd130WC/7kcTlXkfBj2sFaSh+fsWE356D3Wjd9IYcuOAm\n"\
"okULytNOkGCH/rliaZb5Pd0L803IhGNuRjI2/CnHGfrnOycK7JEsHvKuXJmW/gk9\n"\
"zx1LsPvuI1SKYfoRhu9rI3tgDthQSJ/nZECXZDMCgYEAiltaQxJM+oH447jTB2f+\n"\
"5HEklBXTyx+t1pZqRb6kOmKHSps7EhKZhcqzhkNiJdA155fLEi8diRUdTOMuNuw5\n"\
"0ojYl0okI6p2JpchkMdRXtf7+11Jlo3XElOSqoLNX3Z/CeEZZtEt5wVurhmHSOMP\n"\
"+iBy5SVaT5ujaElyRAIQfAECgYEAqXilG5vOAzDW5+o6Mu21R+KbeIJIFac4JvZv\n"\
"RYuzbHvCUsOEdy460AqldPNLyPHMR+5RHYNWuG3jIM5RjgqxV3gRWJqF+m2QbJ8K\n"\
"PndZxfwFoRGjT0WhWe9kaPZu47BxLE2tIsWUUEEmpkXer5UNmz1X6h1w0JqZrf+P\n"\
"9ApTUSsCgYArIiQ+lEyP3aYWy2rff5Ih+h+YtBh+chZgMafNcdyiWaER69CfPo0j\n"\
"JDYw7kAaOwLQl1pg7XcyDVfeDaUWOvJTd307UVnUPcwTLyXrKLVDousF6Z6YScAe\n"\
"Rw15UORXfp7umT8nml0WSMnf/RqG816l66E+cnp2jjFMdt2boowlbg==\n"\
"-----END RSA PRIVATE KEY-----\n"

#endif /* AWS_CLIENT_CREDENTIAL_KEYS_H */
